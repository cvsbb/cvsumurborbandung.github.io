CV SUMUR BOR BANDUNG — WEBSITE VERSI 2 + LANDING PAGE GOOGLE ADS

FILE UTAMA: index.html

CARA PASANG KE GITHUB PAGES:
1. Login https://github.com/cvsbb/cvsumurborbandung.github.io
2. Klik file index.html -> ikon pensil (Edit this file).
3. Hapus semua kode lama, ganti dengan isi index.html baru ini.
4. Klik Commit changes, pilih Commit directly to main, lalu Commit changes.
5. GitHub Pages sudah aktif dari main / (root).
6. Buka https://cvsbb.github.io/cvsumurborbandung.github.io/ dan muat ulang Ctrl+F5.

FITUR:
- Profil, 6 layanan, alur kerja, ilustrasi galeri, FAQ, kebijakan privasi.
- Tombol WhatsApp aktif dan formulir penawaran yang membuat pesan WhatsApp siap dikirim.
- SEO dasar: meta description, Open Graph, canonical dan structured data LocalBusiness.
- Menu mobile, desain responsif, navigasi anchor, aksesibilitas dasar.
- Tanpa server, database dan pelacak Google Ads.

DATA KONTAK:
WhatsApp 081278493876, email cvsumurborbandung@gmail.com, telepon (022) 20682848.
Ditemukan pada situs resmi cvsumurborbandung.com; MOHON VERIFIKASI sebelum iklan dibelanjakan.

CATATAN PRODUKSI DAN IKLAN:
- Galeri menggunakan ILUSTRASI buatan dengan SVG, bukan foto proyek nyata. Ganti dengan foto asli setelah ada izin.
- Logo dalam kode adalah simbol tetesan air generik, bukan logo asli. Ganti dengan aset logo perusahaan.
- Pastikan informasi perusahaan dan alamat operasional benar.
- Jangan pasang tracking Google Ads / GA4 sebelum memperoleh tag ID resmi dan mengatur persetujuan privasi yang diperlukan.
- Formulir tidak mengirim data ke server; pengunjung menekan Kirim sendiri di WhatsApp.
- Untuk Google Ads gunakan URL final yang sesuai dengan domain tujuan iklan; landing page harus berfungsi dan informatif.
- Penggantian ini hanya mengubah repository GitHub Pages, BUKAN WordPress cvsumurborbandung.com.
